import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import {combineLatest, map, Observable, startWith} from 'rxjs';
import { ProductStoreModel } from '../../models/product-store.model';
import { ProductColorModel } from '../../models/product-color.model';
import { ProductModel } from '../../models/product.model';
import { ProductsService } from '../../services/products.service';

@Component({
  selector: 'app-products',
  styleUrls: ['./products.component.scss'],
  templateUrl: './products.component.html',
  encapsulation: ViewEncapsulation.Emulated,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductsComponent {
  readonly searchForm: FormGroup = new FormGroup({
    color: new FormControl(),
    store: new FormControl(),
    term: new FormControl(),
  }
  );
  readonly storeList$: Observable<ProductStoreModel[]> = this._productsService.getStores();
  readonly colorList$: Observable<ProductColorModel[]> = this._productsService.getColors();
  readonly productList$: Observable<ProductModel[]> = combineLatest([
    this._productsService.getAll(),
    this.searchForm.valueChanges.pipe(startWith({color: '', store: '', term: ''})),
  ]).pipe(
    map(([products, search]) =>
      products.filter(product =>
        product.colorId.includes(search.color?.toString() ?? '') &&
        product.storeId.includes(search.store?.toString() ?? '') &&
        (product.name.toLowerCase().includes(search.term.toLowerCase() ?? '') ||
        product.price?.toString().includes(search.term ?? ''))
      )
    )
  )

  constructor(private _productsService: ProductsService) {
  }

}
