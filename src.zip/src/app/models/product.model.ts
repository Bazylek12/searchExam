export interface ProductModel {
  readonly name: string;
  readonly price: number;
  readonly colorId: string;
  readonly storeId: string;
  readonly id: string;
}
