export interface ProductStoreModel {
  readonly name: string;
  readonly id: string;
}
