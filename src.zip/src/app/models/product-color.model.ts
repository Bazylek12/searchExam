export interface ProductColorModel {
  readonly name: string;
  readonly id: string;
}
